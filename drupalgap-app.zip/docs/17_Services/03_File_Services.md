## Create

The **Save file information** permission must be enabled for this to work.

### Example Result

```
{
  "fid":"1",
  "uri":"http://www.example.com/drupalgap/file/1"
}
```